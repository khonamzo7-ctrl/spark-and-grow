SPARK & GROW — WEBSITE

Open index.html in a web browser to preview the website. The site is static and mobile-friendly.

BEFORE GOING LIVE:
1. Open script.js. Set SITE_CONFIG.whatsappNumber to your official business WhatsApp in international format (example 27712345678). Set businessEmail to your official business email, if you want direct contact links.
2. Review all prices and service descriptions in script.js.
3. Replace any business details and verify your business registration and contact information before publishing.
4. Test the enquiry form and direct links on a phone after configuring contact details.
5. Upload all files together to a static web host. index.html must stay alongside styles.css, script.js and favicon.svg.

IMPORTANT: The enquiry form prepares a message on the visitor's device; it does NOT automatically submit messages, store customer records or take payment. Do not advertise it as an online order-processing system until a proper backend has been connected.
